#include <stdlib.h>
#include <string.h>

#define BLEN 1024

int do_something(char *buf);

int main(void)
{
    int ret = 0;
    char *buf;

    /* Initialization */
    buf = malloc(BLEN * sizeof(char));

    /* Do something important with buf... */
    ret = do_something(buf);

    /* Clean up  and terminate */
    memset(buf, 0, sizeof(char) * BLEN); /* Clear the buffer! */
    free(buf);

    return ret;
}

