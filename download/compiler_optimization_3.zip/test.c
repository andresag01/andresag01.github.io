#define CONSTANT (109238)

int notSoLazy(unsigned int x, unsigned int y)
{
    if (y < 32 && x > (CONSTANT << y))
    {
        return (CONSTANT >> y);
    }
    else
    {
        return CONSTANT;
    }
}
